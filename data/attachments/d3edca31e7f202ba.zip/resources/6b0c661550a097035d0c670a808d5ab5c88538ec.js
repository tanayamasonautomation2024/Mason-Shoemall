(function(){self.postMessage("gbDTDWorkerReady");
debugger;

self.onmessage=function(t){t.data&&"gbDTDHello"===t.data&&self.postMessage("gbDTDHi")}})()